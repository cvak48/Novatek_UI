export enum NvColor {
    Color01,
    Color02,
    Color03
}

export enum NvUserColor {
    StateColor01,
    StateColor02,
    StateColor03,
    PriorityColor01,
    PriorityColor02,
    PriorityColor03,
    PriorityColor04,
    None
  }