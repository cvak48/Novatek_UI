import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nv-app-footer',
  templateUrl: './nv-footer.component.html',
  styleUrls: ['./nv-footer.component.scss']
})
export class NvFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
