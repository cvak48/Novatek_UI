import { NvTrimPipe } from './nv-trim.pipe';

describe('NvTrimPipe', () => {
  it('create an instance', () => {
    const pipe = new NvTrimPipe();
    expect(pipe).toBeTruthy();
  });
});
