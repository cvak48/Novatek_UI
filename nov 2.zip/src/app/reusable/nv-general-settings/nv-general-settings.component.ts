import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nv-app-general-settings',
  templateUrl: './nv-general-settings.component.html',
  styleUrls: ['./nv-general-settings.component.scss']
})
export class NvGeneralSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
