import { NvSvgColorDirective } from './nv-svg-color.directive';

describe('NvSvgColorDirective', () => {
  it('should create an instance', () => {
    const directive = new NvSvgColorDirective();
    expect(directive).toBeTruthy();
  });
});
