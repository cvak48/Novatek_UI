import { NvFilterPipe } from './nv-filter.pipe';

describe('NvFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new NvFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
