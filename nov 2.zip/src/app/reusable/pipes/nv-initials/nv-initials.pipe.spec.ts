import { NvInitialsPipe } from './nv-initials.pipe';

describe('NvInitialsPipe', () => {
  it('create an instance', () => {
    const pipe = new NvInitialsPipe();
    expect(pipe).toBeTruthy();
  });
});
