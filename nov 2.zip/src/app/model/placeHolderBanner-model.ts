export interface PlaceHolderBannerModel{
    img: string,
    text1: string,
    text2: string,
    description:string
}