import { BackgroundColorDirective } from './background-color.directive';

describe('BackgroundColorDirective', () => {
  it('should create an instance', () => {
    const directive = new BackgroundColorDirective();
    expect(directive).toBeTruthy();
  });
});
