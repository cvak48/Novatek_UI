import { NvFileUploadDirective } from './nv-file-upload.directive';

describe('NvFileUploadDirective', () => {
  it('should create an instance', () => {
    const directive = new NvFileUploadDirective();
    expect(directive).toBeTruthy();
  });
});
