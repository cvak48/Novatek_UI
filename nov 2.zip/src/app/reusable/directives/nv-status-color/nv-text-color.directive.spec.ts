import { NvTextColorDirective } from './nv-text-color.directive';

describe('NvTextColorDirective', () => {
  it('should create an instance', () => {
    const directive = new NvTextColorDirective();
    expect(directive).toBeTruthy();
  });
});
