import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nv-slider-radio-button',
  templateUrl: './nv-slider-radio-button.component.html',
  styleUrls: ['./nv-slider-radio-button.component.scss']
})
export class NvSliderRadioButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
