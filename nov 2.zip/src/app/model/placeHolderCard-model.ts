export interface PlaceHolderCardModel{
    img: string,
    description:string
}