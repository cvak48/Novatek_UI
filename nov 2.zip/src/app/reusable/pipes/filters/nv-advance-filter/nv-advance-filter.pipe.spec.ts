import { NvAdvanceFilterPipe } from './nv-advance-filter.pipe';

describe('NvAdvanceFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new NvAdvanceFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
