import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nv-user-view',
  templateUrl: './nv-user-view.component.html',
  styleUrls: ['./nv-user-view.component.scss']
})
export class NvUserViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
