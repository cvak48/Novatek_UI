
export interface Team {
    name: string;
    id: string;
    status: string;
    checked : boolean;
}
