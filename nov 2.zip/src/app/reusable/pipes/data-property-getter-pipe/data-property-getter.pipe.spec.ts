import {DataPropertyGetterPipe} from './data-property-getter.pipe';

describe('DataPropertyGetterPipe', () => {
  it('create an instance', () => {
    const pipe = new DataPropertyGetterPipe();
    expect(pipe).toBeTruthy();
  });
});
