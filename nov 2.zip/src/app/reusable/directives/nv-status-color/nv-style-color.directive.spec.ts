import { NvStyleColorDirective } from './nv-style-color.directive';

describe('NvStyleColorDirective', () => {
  it('should create an instance', () => {
    const directive = new NvStyleColorDirective();
    expect(directive).toBeTruthy();
  });
});
